# trade_project
This repository is the starting template for the course project for ITIS 5166. 

The repository includes four files:

- index.html : main page of the application
- trades.html: the listing page
- trade.html: the individual item page
- newTrade.html: adding new item page.
